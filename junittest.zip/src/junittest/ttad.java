package junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ttad {

	testString ts = new testString();
	@Test
	void testCount() {
		//fail("Not yet implemented");
		assertEquals(ts.count("hello", "good"), 0);
	}

	@Test
	void testFillZero() {
		//fail("Not yet implemented");
	}

	@Test
	void testContains() {
		//fail("Not yet implemented");
	}

	@Test
	void testDelChar() {
		//fail("Not yet implemented");
	}

}
