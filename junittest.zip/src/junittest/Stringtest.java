package junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Stringtest {
	testString ts = new testString();

	@Test
	void testCount() {
		assertEquals( ts.count("Hello", "Good"),0);
		assertEquals(1, ts.count("Good", "oo"));
		assertEquals(2, ts.count("Good Afternoon", "oo"));
	}

	@Test
	void testFillZero() {
		assertEquals(null, ts.fillZero(null, 10));
		assertEquals("morning", ts.fillZero("morning", 7));
		assertEquals("mor", ts.fillZero("morning", 3));
		assertEquals("", ts.fillZero("morning", -1));
		assertEquals("000morning", ts.fillZero("morning", 10));
	}

	@Test
	void testContains() {
		assertEquals(true, ts.contains("Good morning", "morning"));
		assertEquals(false, ts.contains("Good morning", "afternoon"));
	}
	@Test
	void testDelChar() {
		assertEquals("01234567", ts.delChar("01234567", "!@#$%^&*()"));
		assertEquals("01234567", ts.delChar("01$234%5(67)", "!@#$%^&*()"));
		assertEquals(" mrning", ts.delChar("Good morning", "God"));
	}

}
